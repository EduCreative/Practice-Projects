# Random Quote Machine (FreeCodeCamp)

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduCreative/pen/vYRRaGq](https://codepen.io/EduCreative/pen/vYRRaGq).

