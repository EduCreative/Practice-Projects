# Create Token

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduCreative/pen/ZExdBwG](https://codepen.io/EduCreative/pen/ZExdBwG).

